import logo from './logo.svg';
import './App.css';
import './style.css';
import './css/all.min.css'

function App() {
  return (
    <>
      <section>
        <header>
          <div className='container'>
            <div className='bg_theme'>
              <div className='logo'>
                <img src={require(`./images/asset 0.png`)}></img>
              </div>

              <div className="menu">
                <ul className="main_menu">
                  <li><a href="#"><span className="home">home</span></a></li>
                  <li><a href="#">about</a></li>
                  <li><a href="#">services</a></li>
                  <li><a href="#">portfolio</a></li>
                  <li><a href="#">blog</a></li>
                  <li><a href="#">contact</a></li>
                </ul>
              </div>
            </div>
          </div>

          {/* first start */}

          <div className="start">
            <div className='text'>
              <span>
                Welcome! <br></br>
                <span className='text0'>
                  I am <span className='text2'>Web Designer</span>
                </span>
              </span>

              <div className='icon'>
                <div className='icon_main'>
                  <i className='fa-brands fa-facebook'></i>
                  <i className='fa-brands fa-twitter'></i>
                  <i className='fa-brands fa-instagram'></i>
                  <i className='fa-brands fa-linkedin'></i>
                  <i className='fa-brands fa-behance'></i>
                </div>
              </div>
            </div>
          </div>

          {/* first end */}

          {/* second start */}

          <section>
            <div className='second'>
              <div className='container'>
                <div className='second1'>
                  <div className='image'>
                    <img src={require(`./images/asset 1.jpeg`)}></img>
                  </div>
                  <div className='font'>
                    <h6>WHO AM I</h6>
                    <h4>Zain Butler.</h4>
                    <h5>Professional Web Designer</h5>
                    <p>
                      Nulla metus metus ullamcorper vel tincidunt sed euismod nibh Quisque volutpat condimentum velit class aptent taciti sociosqu ad litora torquent metus metus ullamcorper.
                    </p>
                    <p className='p2'>
                      Nulla metus metus ullamcorper vel tincidunt sed euismod nibh Quisque volutpat condimentum velit class aptent taciti sociosqu ad litora torquent metus metus ullamcorper vel tincidunt sed class aptent taciti sociosqu ad litora torquent type setting industry when per conubia nostra.
                    </p>

                    <div className='btn'>
                      <button className='btn1'><span>Download CV</span></button>
                      <button className='btn2'><span>Hire Me!</span></button>
                    </div>

                  </div>
                </div>
              </div>
            </div>
          </section>

          {/* second end */}

        </header>
      </section>

      {/* Third start */}

      <sectin>

        <div className='third'>
          <div className='container'>
            <h4>Services</h4>
            {/* box start */}
            <div className='box'>

              <div className='box1'>
                <div className='small'>
                  <i class="fa-solid fa-palette color"></i>
                </div>
                <h6>Web Design</h6>
                <p>Nulla metus metus ullamcorper vel tincidunt sed euismod nibh Quisque volutpat</p>
              </div>

              <div className='box1'>
                <div className='small'>
                  <i class="fa-solid fa-shield color"></i>
                </div>
                <h6>Development</h6>
                <p>Nulla metus metus ullamcorper vel tincidunt sed euismod nibh Quisque volutpat</p>
              </div>

              <div className='box1'>
                <div className='small'>
                  <i class="fa-solid fa-pen-ruler color"></i>
                </div>
                <h6>Branding</h6>
                <p>Nulla metus metus ullamcorper vel tincidunt sed euismod nibh Quisque volutpat</p>
              </div>

              <div className='box1'>
                <div className='small'>
                  <i class="fa-solid fa-money-bill-trend-up color"></i>
                </div>
                <h6>Marketing</h6>
                <p>Nulla metus metus ullamcorper vel tincidunt sed euismod nibh Quisque volutpat</p>
              </div>

            </div>
            {/* box end */}
          </div>
        </div>

      </sectin>

      {/* Third end */}

      {/* start four */}

      <section>

        <div className='four'>
          <div className='container'>
            <h4>Portfolio</h4>
            <div className='menu'>
              <ul className='main_menu'>
                <li><a href="#"><span>ALL</span></a></li>
                <li><a href="#">BRAND</a></li>
                <li><a href="#">DESIGN</a></li>
                <li><a href="#">GRAPHIC</a></li>
              </ul>
            </div>

            {/* Gallery */}

            <div className='image_1'>
              <div className='row'>
                <div className='port_main'>
                  <img className='img1' src={require(`./images/asset 2.jpeg`)}></img>
                  <div className='port_on'>
                    <h6>Crearive Design</h6>
                    <p>Work description here</p>
                  </div>
                </div>

                <img className='img2' src={require(`./images/asset 3.jpeg`)}></img>
                <img className='img3' src={require(`./images/asset 6.jpeg`)}></img>
                <img className='img4' src={require(`./images/asset 4.jpeg`)}></img>
                <img className='img5' src={require(`./images/asset 5.jpeg`)}></img>
                <img className='img6' src={require(`./images/asset 8.jpeg`)}></img>
                <img className='img7' src={require(`./images/asset 7.jpeg`)}></img>
              </div>
            </div>
          </div>
        </div>

      </section>

      {/* end four */}

      {/* start five */}

      <section>

        <div className='five'>
          <div className='container'>
            <h4>Our Blog</h4>

            <div className='image_gal'>

              <div className='box_1'>
                <img src={require(`./images/asset 9.jpeg`)}></img>
                <div className='content'>
                  <div className='text_in'>
                    <a href="#" ><span className='on'>WordPress</span></a>
                    <a href="#"><span>March 21 - 2018</span></a>
                    <h5>
                      <a href="#">Your ideal WordPress <br></br> theme is here.</a>
                    </h5>
                    <div className='read'>
                      <a href="#">Read More</a>
                    </div>
                  </div>
                </div>
              </div>

              <div className='box_1'>
                <img src={require(`./images/asset 10.jpeg`)}></img>
                <div className='content'>
                  <div className='text_in'>
                    <a href="#" ><span className='on'>WordPress</span></a>
                    <a href="#"><span>March 21 - 2018</span></a>
                    <h5>
                      <a href="#">Your ideal WordPress <br></br> theme is here.</a>
                    </h5>
                    <div className='read'>
                      <a href="#">Read More</a>
                    </div>
                  </div>
                </div>
              </div>

              <div className='box_1'>
                <img src={require(`./images/asset 11.jpeg`)}></img>
                <div className='content'>
                  <div className='text_in'>
                    <a href="#" ><span className='on'>WordPress</span></a>
                    <a href="#"><span>March 21 - 2018</span></a>
                    <h5>
                      <a href="#">Your ideal WordPress <br></br> theme is here.</a>
                    </h5>
                    <div className='read'>
                      <a href="#">Read More</a>
                    </div>
                  </div>
                </div>
              </div>

            </div>

          </div>
        </div>

      </section>

      {/* end five */}

      {/* Footer start */}

      <section>

        <div className='footer'>
          <div className='container'>
            <h4>Contact Us</h4>
            <div className='flex'>
              <div className='contact'>
                <img src={require(`./images/asset 13.png`)}></img>

                <div className='contact_2'>
                  <div className='item'>
                    <div className='cont'>
                      <h6>phone :</h6>
                      <p>+20 010 2517 8918</p>
                    </div>
                  </div>

                  <div className='item'>
                    <div className='cont'>
                      <h6>Address :</h6>
                      <p>3rd Avenue, Upper East Side, <br></br>  San Francisco</p>
                    </div>
                  </div>

                  <div className='item'>
                    <div className='cont'>
                      <h6>EMAIL :</h6>
                      <p>email_support@youradress.com</p>
                    </div>
                  </div>
                </div>

              </div>

              <div className='input'>
                <input type="text" className='pad' placeholder="Name"></input>
                <input type="text" className='pad2' placeholder="Email"></input>
                <input type="text" className='last' placeholder="Subject"></input>
                <textarea row='4' cols='25' placeholder="Message"></textarea>
                <button className='btn1'><span>Send Message</span></button>
              </div>

            </div>
          </div>
        </div>

      </section>

      <section>

        <div className='end'>
          <div className='container'>
            <div className='end_img'>
              <img src={require(`./images/asset 0.png`)}></img>
            </div>

            <div className='end_icon'>
              <div className='small_1'>
                <i className='fa-brands fa-facebook'></i>
              </div>

              <div className='small_1'>
                <i className='fa-brands fa-twitter'></i>
              </div>

              <div className='small_1'>
                <i className='fa-brands fa-instagram'></i>
              </div>

              <div className='small_1'>
                <i className='fa-brands fa-linkedin'></i>
              </div>

              <div className='small_1'>
                <i className='fa-brands fa-behance'></i>
              </div>
            </div>
            <p>© 2018 UI-ThemeZ. All Rights Reserved.</p>
          </div>
        </div>

      </section>

      {/* Footer end */}
    </>
  );
}

export default App;
